Dim WshShell, FSO, Src, Dst, Desk, sc, f, PythonExe, R, ExeTarget, ExeArgs, name
Dim objFolder, subf, localAppData, localShuaka, localDir1, srcDir1, localDir2, srcDir2

Set WshShell = WScript.CreateObject("WScript.Shell")
Set FSO = WScript.CreateObject("Scripting.FileSystemObject")

Src = FSO.GetParentFolderName(WScript.ScriptFullName)
Dst = "C:\Shuaka"
Desk = WshShell.SpecialFolders("Desktop")

MsgBox "Qiandao Setup will now install." & vbCrLf & vbCrLf & _
       "Existing data will NOT be overwritten." & vbCrLf & _
       "Python will be installed if needed.", vbInformation, "Qiandao Setup"

' Find or Install Python
PythonExe = ""
On Error Resume Next
PythonExe = Trim(WshShell.Exec("cmd /c where python 2>nul").StdOut.ReadLine())
On Error Goto 0

If PythonExe = "" Then
    R = MsgBox("Python not found. Install Python 3.12 automatically?" & vbCrLf & _
        "This requires internet access.", vbYesNo + vbQuestion, "Python Required")
    If R = vbYes Then
        R = WshShell.Run("cmd /c winget install Python.Python.3.12 --accept-source-agreements --accept-package-agreements", 1, True)
        On Error Resume Next
        PythonExe = Trim(WshShell.Exec("cmd /c where python 2>nul").StdOut.ReadLine())
        On Error Goto 0
    End If
End If

If PythonExe = "" Then
    MsgBox "Python 3.12 is required." & vbCrLf & vbCrLf & _
           "Download from: python.org/downloads/" & vbCrLf & _
           "Then run setup.vbs again.", vbCritical, "Error"
    WScript.Quit 1
End If

' Create base directories
If Not FSO.FolderExists(Dst) Then FSO.CreateFolder(Dst)
If Not FSO.FolderExists(Dst & "\tablet") Then FSO.CreateFolder(Dst & "\tablet")
If Not FSO.FolderExists(Dst & "\local_backup") Then FSO.CreateFolder(Dst & "\local_backup")

' BaiduSyncdisk: keep existing data, only create if missing
If Not FSO.FolderExists(Dst & "\BaiduSyncdisk") Then
    FSO.CreateFolder(Dst & "\BaiduSyncdisk")
End If


' Copy CODE files (skip data files)
Set objFolder = FSO.GetFolder(Src & "\shuaka")
For Each f In objFolder.Files
    name = f.Name
    If name <> "settings.json" And name <> "users.json" And name <> "machine.json" Then
        FSO.CopyFile f.Path, Dst & "\", True
    End If
Next

If FSO.FolderExists(Src & "\shuaka\tablet") Then
    Set objFolder = FSO.GetFolder(Src & "\shuaka\tablet")
    For Each f In objFolder.Files
        FSO.CopyFile f.Path, Dst & "\tablet\", True
    Next
End If

If FSO.FileExists(Src & "\icon.ico") Then
    FSO.CopyFile Src & "\icon.ico", Dst & "\icon.ico", True
End If

' Copy subfolders (skip data folders)
If FSO.FolderExists(Src & "\shuaka") Then
    Set objFolder = FSO.GetFolder(Src & "\shuaka")
    For Each subf In objFolder.SubFolders
        name = subf.Name
        If name <> "BaiduSyncdisk" And name <> "local_backup" And name <> "tablet" Then
            If Not FSO.FolderExists(Dst & "\" & name) Then
                FSO.CopyFolder subf.Path, Dst & "\" & name, True
            End If
        End If
    Next
End If

' Install dependencies
R = WshShell.Run("cmd /c cd /d " & Chr(34) & Dst & Chr(34) & " && " & Chr(34) & PythonExe & Chr(34) & " -m pip install -r requirements.txt --disable-pip-version-check -q && echo Dependencies OK && pause", 1, True)

' Desktop shortcut
If FSO.FileExists(Dst & "\qiandao.exe") Then
    ExeTarget = Dst & "\qiandao.exe"
    ExeArgs = ""
ElseIf FSO.FileExists(Dst & "\desktop_app.py") Then
    ExeTarget = "pythonw.exe"
    ExeArgs = Chr(34) & Dst & "\desktop_app.py" & Chr(34)
Else
    ExeTarget = "pythonw.exe"
    ExeArgs = Chr(34) & Dst & "\main.py" & Chr(34)
End If

Set sc = WshShell.CreateShortcut(Desk & "\Qiandao.lnk")
sc.TargetPath = ExeTarget
sc.Arguments = ExeArgs
sc.IconLocation = Dst & "\icon.ico,0"
sc.WorkingDirectory = Dst
sc.Save

' Auto-start
On Error Resume Next
If FSO.FileExists(Dst & "\qiandao.exe") Then
    WshShell.RegWrite "HKCU\Software\Microsoft\Windows\CurrentVersion\Run\Qiandao", Chr(34) & Dst & "\qiandao.exe" & Chr(34), "REG_SZ"
ElseIf FSO.FileExists(Dst & "\desktop_app.py") Then
    WshShell.RegWrite "HKCU\Software\Microsoft\Windows\CurrentVersion\Run\Qiandao", "pythonw.exe " & Chr(34) & Dst & "\desktop_app.py" & Chr(34), "REG_SZ"
Else
    WshShell.RegWrite "HKCU\Software\Microsoft\Windows\CurrentVersion\Run\Qiandao", "pythonw.exe " & Chr(34) & Dst & "\main.py" & Chr(34), "REG_SZ"
End If
On Error Goto 0

' Launch
If FSO.FileExists(Dst & "\qiandao.exe") Then
    WshShell.Run Chr(34) & Dst & "\qiandao.exe" & Chr(34), 1, False
ElseIf FSO.FileExists(Dst & "\desktop_app.py") Then
    WshShell.Run "pythonw.exe " & Chr(34) & Dst & "\desktop_app.py" & Chr(34), 1, False
Else
    WshShell.Run "pythonw.exe " & Chr(34) & Dst & "\main.py" & Chr(34), 1, False
End If
WScript.Sleep 5000
WshShell.Run "http://localhost:5002"

MsgBox "Installation Complete!" & vbCrLf & vbCrLf & _
       "Desktop: Qiandao" & vbCrLf & _
       "Display: http://localhost:5002" & vbCrLf & _
       "Admin:  http://localhost:5002/admin" & vbCrLf & _
       "Account: admin / admin123" & vbCrLf & vbCrLf & _
       "Auto-start: enabled", vbInformation, "Qiandao Setup"
